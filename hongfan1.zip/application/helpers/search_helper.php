<?php 

//商家商品搜索
function search_store_goods($storeid,$cate,$startPrice,$endPrice,$startRepertory,$endRepertory,$state,$sear,$differentiate){
            $CI = &get_instance();
            $res= '';
            if(!empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                
                 $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                 $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('price >=',$startPrice)->where('price <=',$endPrice)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where("goods_state",$state)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){

                 $sql = "SELECT a.*,b.catid from hf_mall_goods as a,hf_mall_category as b where a.categoryid = b.catid and storeid = '$storeid' and differentiate = '$differentiate' and concat(title, goods_code) like '%$sear%'";
                 $query = $CI->db->query($sql);
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('goods_state',$state)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                  if($state == ''){
                    $state = '0';
                } 

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('goods_state',$state)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state != '' && empty($sear)){
                  if($state == ''){
                    $state = '0';
                }

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->where('goods_state',$state)->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state == '' && !empty($sear)){

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state != '' && !empty($sear)){
                  if($state == ''){
                    $state = '0';
                }

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('goods_state',$state)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){

                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('goods_state',$state)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->get();
                 $res = $query->result_array();
                
            }else 
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                  $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('goods_state',$state)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->where('goods_state',$state)->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->where('goods_state',$state)->or_like('goods_code',$sear,'both')->like('title','both')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('goods_state',$state)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state != '' && !empty($sear)){
                  if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->or_like('goods_code',$sear,'both')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
               
            }else if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->where('categoryid',$cate)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->order_by('create_time','desc')->get();
                  $res = $query->result_array();
            }else if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                 $CI->db->select('a.*, b.catname as catname');
                 $CI->db->from('hf_mall_goods a');
                 $CI->db->join('hf_mall_category b', 'b.catid = a.categoryid','left');
                 $query = $CI->db->where('differentiate',$differentiate)->where('storeid',$storeid)->order_by('create_time','desc')->get();
                  $res = $query->result_array();
            }
            return $res;
}
//帮帮团成员搜索
function search_help_user($name,$area,$address,$occupation,$sear){
      $CI = &get_instance();
      $res= '';
      if(!empty($name) && empty($area) && empty($address) && empty($occupation) && empty($sear)){
            $query = $CI->db->where('name',$name)->where('profession_type','1')->get('hf_service_help_user');
            $res = $query->result_array();
      }else
      if(empty($name) && !empty($area) && empty($address) && empty($occupation) && empty($sear)){
          $query = $CI->db->where('area',$area)->where('profession_type','1')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && empty($area) && !empty($address) && empty($occupation) && empty($sear)){
          $query = $CI->db->where('address',$address)->where('profession_type','1')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && empty($area) && empty($address) && !empty($occupation) && empty($sear)){
          $query = $CI->db->where('occupation',$occupation)->where('profession_type','1')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && empty($area) && empty($address) && empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(!empty($name) && !empty($area) && empty($address) && empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(!empty($name) && empty($area) && !empty($address) && empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('name',$name)->where('address',$address)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(!empty($name) && empty($area) && empty($address) && !empty($occupation) && empty($sear)){
         $query = $CI->db->where('profession_type','1')->where('name',$name)->where('occupation',$occupation)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(!empty($name) && empty($area) && empty($address) && empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('name',$name)->like('name',$sear,'both')->like('occupation',$sear,'both')->like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(empty($name) && !empty($area) && !empty($address) && empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->where('address',$address)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(empty($name) && !empty($area) && empty($address) && !empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->where('occupation',$occupation)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && !empty($area) && empty($address) && empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && empty($area) && !empty($address) && !empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('address',$address)->where('occupation',$occupation)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && empty($area) && !empty($address) && empty($occupation) && !empty($sear)){
        $query = $CI->db->where('profession_type','1')->where('address',$address)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && empty($area) && empty($address) && !empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(!empty($name) && !empty($area) && !empty($address) && empty($occupation) && empty($sear)){
         $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->where('address',$address)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(!empty($name) && !empty($area) && empty($address) && !empty($occupation) && empty($sear)){
         $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->where('occupation',$occupation)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(!empty($name) && !empty($area) && empty($address) && empty($occupation) && !empty($sear)){
         $query = $CI->db->where('profession_type','1')->where('address',$address)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(empty($name) && !empty($area) && !empty($address) && !empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->where('address',$address)->where('occupation',$occupation)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(empty($name) && !empty($area) && !empty($address) && empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->where('address',$address)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(empty($name) && empty($area) && !empty($address) && !empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('address',$address)->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(!empty($name) && empty($area) && !empty($address) && !empty($occupation) && empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('name',$name)->where('address',$address)->where('occupation',$occupation)->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(!empty($name) && empty($area) && empty($address) && !empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('name',$name)->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && !empty($area) && empty($address) && !empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
      if(empty($name) && !empty($area) && !empty($address) && !empty($occupation) && !empty($sear)){
          $query = $CI->db->where('profession_type','1')->where('area',$area)->where('address',$address)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }else
       if(!empty($name) && !empty($area) && !empty($address) && !empty($occupation) && empty($sear)){
            $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->where('address',$address)->where('occupation',$occupation)->get('hf_service_help_user');
            $res = $query->result_array();
      }else
      if(!empty($name) && !empty($area) && !empty($address) && empty($occupation) && !empty($sear)){
        $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->where('address',$address)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
         $res = $query->result_array();
      }else
      if(!empty($name) && !empty($area) && empty($address) && !empty($occupation) && !empty($sear)){

        $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->where('occupation',$occupation)->or_like('name',$sear,'both')->or_like('occupation',$sear,'both')->like('competency',$sear,'both')->get('hf_service_help_user');
         $res = $query->result_array();
      }else
       if(!empty($name) && empty($area) && !empty($address) && !empty($occupation) && !empty($sear)){
        $query = $CI->db->where('profession_type','1')->where('name',$name)->where('address',$address)->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
         $res = $query->result_array();
      }else
      if(empty($name) && !empty($area) && !empty($address) && !empty($occupation) && !empty($sear)){
        $query = $CI->db->where('profession_type','1')->where('area',$area)->where('address',$address)->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
         $res = $query->result_array();
      }else
      if(!empty($name) && !empty($area) && !empty($address) && !empty($occupation) && !empty($sear)){
         $query = $CI->db->where('profession_type','1')->where('name',$name)->where('area',$area)->where('address',$address)->where('occupation',$occupation)->like('name',$sear,'both')->or_like('occupation',$sear,'both')->or_like('competency',$sear,'both')->get('hf_service_help_user');
          $res = $query->result_array();
      }
      return $res;
}

//帮帮团请求搜索
function search_help_request($userid,$helperid,$state,$sear){
    $CI = &get_instance();
    $res = '';
    if(!empty($userid) && empty($helperid) && $state == '' && empty($sear)){
        $query = $CI->db->where('user_id',$userid)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(empty($userid) && !empty($helperid) && $state == '' && empty($sear)){
        $query = $CI->db->where('helper_id',$helperid)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(empty($userid) && empty($helperid) && $state != '' && empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('state',$state)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(empty($userid) && empty($helperid) && $state == '' && !empty($sear)){
        $query = $CI->db->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
        $res = $query->result_array();
    }else
    //二组
    if(!empty($userid) && !empty($helperid) && $state == '' && empty($sear)){
        $query = $CI->db->where('user_id',$userid)->where('helper_id',$helperid)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(!empty($userid) && empty($helperid) && $state != '' && empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('user_id',$userid)->where('state',$state)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(!empty($userid) && empty($helperid) && $state == '' && !empty($sear)){
         $query = $CI->db->where('user_id',$userid)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
         $res = $query->result_array();
    }else
    if(empty($userid) && !empty($helperid) && $state != '' && empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('helper_id',$helperid)->where('state',$state)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(empty($userid) && !empty($helperid) && $state == '' && !empty($sear)){
         $query = $CI->db->where('helper_id',$helperid)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
         $res = $query->result_array();
    }else
    if(empty($userid) && empty($helperid) && $state != '' && !empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('state',$state)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
         $res = $query->result_array();
    }else
    //三组
    if(!empty($userid) && !empty($helperid) && $state != '' && empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where("user_id",$userid)->where('helper_id',$helperid)->where('state',$state)->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(!empty($userid) && !empty($helperid) && $state == '' && !empty($sear)){
        $query = $CI->db->where("user_id",$userid)->where('helper_id',$helperid)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(!empty($userid) && empty($helperid) && $state != '' && !empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where("user_id",$userid)->where('state',$state)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(empty($userid) && !empty($helperid) && $state != '' && !empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where("helper_id",$helperid)->where('state',$state)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(!empty($userid) && !empty($helperid) && $state != '' && !empty($sear)){
          if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('user_id',$userid)->where("helper_id",$helperid)->where('state',$state)->like('title',$sear,'both')->like('content',$sear,'both')->get('hf_service_request');
        $res = $query->result_array();
    }else
    if(empty($userid) && empty($helperid) && $state == '' && empty($sear)){
        $query = $CI->db->get('hf_service_request');
        $res = $query->result_array();
    }
    return $res;
}


//管理 员商品搜索
function search_goods($diff,$cate,$state,$sear,$startPrice,$endPrice,$startRepertory,$endRepertory){
            $CI = &get_instance();
            $res= '';
            if(!empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                 $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('price >=',$startPrice)->where('price <=',$endPrice)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where("goods_state",$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->like("title",$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('goods_state',$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                } 

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('goods_state',$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                }

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->where('goods_state',$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state == '' && !empty($sear)){

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state != '' && !empty($sear)){
                 if($state == ''){
                    $state = '0';
                }

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('goods_state',$state)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && empty($sear)){

                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('goods_state',$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
                
            }else 
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                  $query = $CI->db->where('differentiate',$diff)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(empty($cate) && empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->where('goods_state',$state)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->where('goods_state',$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state == '' && !empty($sear)){
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->where('goods_state',$state)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else 
            if(empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('goods_state',$state)->where('amount >=',$startRepertory)->where('amount <=',$endRepertory)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                $res = $query->result_array();
            }else
            if(!empty($cate) && !empty($startPrice) && empty($startRepertory) && $state != '' && !empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                 $res = $query->result_array();
               
            }else if(!empty($cate) && !empty($startPrice) && !empty($startRepertory) && $state != '' && !empty($sear)){
                 if($state == ''){
                    $state = '0';
                }
                $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->where('categoryid',$cate)->where('goods_state',$state)->where('price >=',$startPrice)->where('price <=',$endPrice)->where('price >=',$startPrice)->where('price <=',$endPrice)->like('title',$sear,'both')->order_by('create_time','desc')->order_by('create_time','desc')->get();
                  $res = $query->result_array();
            }else if(empty($cate) && empty($startPrice) && empty($startRepertory) && $state == '' && empty($sear)){

                 $CI->db->select('a.*,b.store_name,c.catname');
                $CI->db->from('hf_mall_goods as a');
                $CI->db->join('hf_shop_store as b','a.storeid = b.store_id','left');
                $CI->db->join('hf_mall_category as c','a.categoryid = c.catid','left');
                 $query = $CI->db->where('differentiate',$diff)->order_by('create_time','desc')->order_by('create_time','desc')->get();
                  $res = $query->result_array();
            }
            return $res;
}

//管理员订单搜索
function order_search($state,$buyer,$seller,$time,$endtime,$type){
      $CI = &get_instance();
      $res = '';
      if(!empty($state) && empty($buyer) && empty($seller) && empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(empty($state) && !empty($buyer) && empty($seller) && empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('buyer',$buyer)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(empty($state) && empty($buyer) && !empty($seller) && empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('seller',$seller)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();

      }else
      if(empty($state) && empty($buyer) && empty($seller) && !empty($time)){
            $CI->db->select('a.*,b.store_name,c.username,c.nickname');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      //两组
    
      if(!empty($state) && !empty($buyer) && empty($seller) && empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->where('buyer',$buyer)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(!empty($state) &&  empty($buyer) && !empty($seller) && empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->where('seller',$seller)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(!empty($state) &&  empty($buyer) && empty($seller) && !empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where("order_status",$state)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      
       if(empty($state) &&  !empty($buyer) && !empty($seller) && empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('buyer',$buyer)->where('seller',$seller)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
       if(empty($state) &&  !empty($buyer) && empty($seller) && !empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('buyer',$buyer)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
       if(empty($state) && empty($buyer) && !empty($seller) && !empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('seller',$seller)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      //三组
    
      if(empty($state) && !empty($buyer) && !empty($seller) && !empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('buyer',$buyer)->where('seller',$seller)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(!empty($state) && empty($buyer) && !empty($seller) && !empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->where('seller',$seller)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(!empty($state) && !empty($buyer) && !empty($seller) && empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->where('seller',$seller)->where('buyer',$buyer)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(!empty($state) && !empty($buyer) && empty($seller) && !empty($time)){
             $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->where('buyer',$buyer)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      //四组
      if(!empty($state) && !empty($buyer) && !empty($seller) && !empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->where('order_status',$state)->where('seller',$seller)->where('buyer',$buyer)->where('a.create_time >',$time)->where('a.create_time <',$endtime)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }else
      if(empty($state) && empty($buyer) && empty($seller) && empty($time)){
            $CI->db->select('a.*,b.store_name,c.username');
            $CI->db->from('hf_mall_order as a');
            $CI->db->join('hf_shop_store as b','a.seller = b.store_id','left');
            $CI->db->join('hf_user_member as c','a.buyer = c.user_id','left');
            $query = $CI->db->where('order_type',$type)->order_by('a.create_time','desc')->get();
            $res = $query->result_array();
      }
      return $res;
}


//管理员搜索商家
function search_store_list($yetai,$state,$floor,$berth,$sear){
    $CI = &get_instance();
  
    $res= '';
    if(!empty($yetai) && $state == '' && empty($floor) && empty($berth) && empty($sear)){
        $query = $CI->db->where('commercial_type_name',$yetai)->order_by('create_time','desc')->get('hf_shop_store');
        $res = $query->result_array();
    }else
    if(empty($yetai) && $state != '' && empty($floor) && empty($berth) && empty($sear)){
        if($state == ''){
            $state = '0';
        }
         $query = $CI->db->where('state',$state)->order_by('create_time','desc')->get('hf_shop_store');
        $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && !empty($floor) && empty($berth) && empty($sear)){
         $query = $CI->db->where('floor_name',$floor)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && empty($floor) && !empty($berth) && empty($sear)){
        $query = $CI->db->where('door_no',$berth)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && empty($floor) && empty($berth) && !empty($sear)){
        $query = $CI->db->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    //二组
    if(!empty($yetai) && $state == '' && empty($floor) && empty($berth) && empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('commercial_type_name',$yetai)->where('state',$state)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state == '' && !empty($floor) && empty($berth) && empty($sear)){
        $query = $CI->db->where('commercial_type_name',$yetai)->where('floor_name',$floor)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state == '' && empty($floor) && !empty($berth) && empty($sear)){
        $query = $CI->db->where('commercial_type_name',$yetai)->where('door_no',$berth)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state == '' && empty($floor) && empty($berth) && !empty($sear)){
        $query = $CI->db->where('commercial_type_name',$yetai)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && !empty($floor) && empty($berth) && empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('floor_name',$floor)->where('state',$state)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && empty($floor) && !empty($berth) && !empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('door_no',$berth)->where('state',$state)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && empty($floor) && empty($berth) && !empty($sear)){
        if($state == ''){
            $state = '0';
        }
        $query = $CI->db->where('state',$state)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && !empty($floor) && !empty($berth) && empty($sear)){

        $query = $CI->db->where('floor_name',$floor)->where('door_no',$berth)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && empty($floor) && !empty($berth) && !empty($sear)){
        $query = $CI->db->where('door_no',$berth)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
     }else
    // //三组
    if(!empty($yetai) && $state != '' && !empty($floor) && empty($berth) && empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('commercial_type_name',$yetai)->where('state',$state)->where('floor_name',$floor)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state != '' && empty($floor) && !empty($berth) && empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('commercial_type_name',$yetai)->where('state',$state)->where('door_no',$berth)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state != '' && empty($floor) && empty($berth) && !empty($sear)){
         if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('commercial_type_name',$yetai)->where('state',$state)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state != '' && !empty($floor) && !empty($berth) && empty($sear)){
         if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('floor_name',$floor)->where('state',$state)->where('door_no',$berth)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state != '' && !empty($floor) && empty($berth) && !empty($sear)){
         if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('floor_name',$floor)->where('state',$state)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state != '' && empty($floor) && !empty($berth) && !empty($sear)){
         if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('door_no',$berth)->where('state',$state)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && !empty($floor) && !empty($berth) && !empty($sear)){
       
        $query = $CI->db->where('floor_name',$floor)->where('door_no',$berth)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state == '' && empty($floor) && !empty($berth) && !empty($sear)){
        
        $query = $CI->db->where('commercial_type_name',$yetai)->where('door_no',$berth)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state == '' && !empty($floor) && empty($berth) && !empty($sear)){
         
        $query = $CI->db->where('commercial_type_name',$yeai)->where('floor_name',$floor)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    //sizu
    if(!empty($yetai) && $state != '' && !empty($floor) && empty($berth) && !empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('commercial_type_name',$yeai)->where('state',$state)->where('floor_name',$floor)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state != '' && !empty($floor) && !empty($berth) && empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('commercial_type_name',$yeai)->where('state',$state)->where('floor_name',$floor)->where('door_no',$berth)->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state != '' && !empty($floor) && !empty($berth) && !empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('door',$berth)->where('state',$state)->where('floor_name',$floor)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state == '' && !empty($floor) && !empty($berth) && !empty($sear)){
        if($state = ''){
            $state = '0';
        }
         $query = $CI->db->where('door',$berth)->where('commercial_type_name',$yetai)->where('floor_name',$floor)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state != '' && empty($floor) && !empty($berth) && !empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('door',$berth)->where('commercial_type_name',$yetai)->where('state',$state)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(!empty($yetai) && $state != '' && !empty($floor) && !empty($berth) && !empty($sear)){
        if($state = ''){
            $state = '0';
        }
        $query = $CI->db->where('door',$berth)->where('commercial_type_name',$yetai)->where('state',$state)->where('floor_name',$floor)->like('store_name',$sear,'both')->or_like('barnd_name',$sear,'both')->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }else
    if(empty($yetai) && $state == '' && empty($floor) && empty($berth) && empty($sear)){
        $query = $CI->db->order_by('create_time','desc')->get('hf_shop_store');
         $res = $query->result_array();
    }
    return $res;
}


//财务导出订单
function moll_order_list($storeid,$time,$endtime){
      $CI = &get_instance();
      $res= '';
      if(empty($time)){
            if($storeid == '-2'){
                $sql = "SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '4' AND `order_type` != '0' union all SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '5' AND `order_type` != '0' ORDER BY `create_time` DESC";
                $query = $CI->db->query($sql);
                $res = $query->result_array();
            }elseif($storeid == '-1'){
                $sql = "SELECT * FROM `hf_mall_order` WHERE `seller` = '0' AND `order_status` = '4' union all SELECT * FROM `hf_mall_order` WHERE `seller` = '0' AND `order_status` = '5' ORDER BY `create_time` DESC";
                $query = $CI->db->query($sql);
                $res = $query->result_array();
            }else{
                $sql = "SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '4' AND `seller` = '$storeid' union all SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '5' AND `seller` = '$storeid' ORDER BY `create_time` DESC";
                $query = $CI->db->query($sql);
              //  $query = $CI->db->where('order_status =','4,5')->where('seller',$storeid)->order_by('a.create_time','desc')->get();
                $res = $query->result_array();
            }
      }else{
            if($storeid == '-2'){
                $sql = "SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '4' AND `order_type` != '0' AND `a`.`create_time` >= '2017-05-04' AND `a`.`create_time` <= '2017-05-30' union all SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '5' AND `order_type` != '0' AND `a`.`create_time` >= '2017-05-04' AND `a`.`create_time` <= '2017-05-30' ORDER BY `create_time` DESC";
                $query = $CI->db->query($sql);
                $res = $query->result_array();
            }elseif($storeid == '-1'){
                $sql = "SELECT * FROM `hf_mall_order` WHERE `seller` = '0' AND `order_status` = '4' AND `a`.`create_time` >= '2017-05-04' AND `a`.`create_time` <= '2017-05-30' union all SELECT * FROM `hf_mall_order` WHERE `seller` = '0' AND `order_status` = '5' AND `a`.`create_time` >= '2017-05-04' AND `a`.`create_time` <= '2017-05-30' ORDER BY `create_time` DESC";
                $query = $CI->db->query($sql);
                $res = $query->result_array();
            }else{
                $sql = "SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '4' AND `seller` = '$storeid' AND `a`.`create_time` >= '2017-05-04' AND `a`.`create_time` <= '2017-05-30' union all SELECT `a`.*, `b`.`store_name` FROM `hf_mall_order` as `a` LEFT JOIN `hf_shop_store` as `b` ON `a`.`seller` = `b`.`store_id` WHERE `order_status` = '5' AND `seller` = '$storeid' AND `a`.`create_time` >= '2017-05-04' AND `a`.`create_time` <= '2017-05-30' ORDER BY `create_time` DESC";
                $query = $CI->db->query($sql);                
                $res = $query->result_array();
            }

      }

      return $res;

}

//发现帖子搜所
function findContent_search($cateid,$sear,$special,$time,$endtime,$likenum){
        $CI = &get_instance();
        $res= '';
        //判断条件
        if(!empty($cateid) && empty($sear) && empty($special) && empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(empty($cateid) && !empty($sear) && empty($special) && empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->like('content',$sear,'both')->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(empty($cateid) && empty($sear) && !empty($special) && empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->like('q_id',$special,'both')->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(empty($cateid) && empty($sear) && empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(empty($cateid) && empty($sear) && empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          //er
        }elseif(!empty($cateid) && !empty($sear) && empty($special) && empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->like('content',$sear,'both')->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(!empty($cateid) && empty($sear) && !empty($special) && empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('q_id',$special)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(!empty($cateid) && empty($sear) && empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(!empty($cateid) && empty($sear) && empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && !empty($sear) && !empty($special) && empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->like('content',$sear,'both')->where('q_id',$special)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && !empty($sear) && empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->like('content',$sear,'both')->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && !empty($sear) && empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->like('content',$sear,'both')->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && empty($sear) && !empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('q_id',$special)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && empty($sear) && !empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('q_id',$special)->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && empty($sear) && empty($special) && !empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        //san
        }elseif(!empty($cateid) && !empty($sear) && !empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->like('content',$sear,'both')->where('q_id',$special)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(!empty($cateid) && !empty($sear) && empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->like('content',$sear,'both')->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(!empty($cateid) && !empty($sear) && empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && !empty($sear) && !empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('q_id',$special)->like('content',$sear,'both')->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && !empty($sear) && !empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('q_id',$special)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && empty($sear) && !empty($special) && !empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('q_id',$special)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();

         //si 
        }elseif(!empty($cateid) && !empty($sear) && !empty($special) && !empty($time) && empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('q_id',$special)->like('content',$sear,'both')->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(!empty($cateid) && !empty($sear) && !empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('q_id',$special)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && !empty($sear) && !empty($special) && !empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('q_id',$special)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(!empty($cateid) && empty($sear) && !empty($special) && !empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('q_id',$special)->where('likeNumber >=',$likenum)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }elseif(!empty($cateid) && !empty($sear) && empty($special) && !empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(!empty($cateid) && !empty($sear) && !empty($special) && empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('q_id',$special)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
            
          //wu
        }elseif(!empty($cateid) && !empty($sear) && !empty($special) && !empty($time) && !empty($likenum)){
            $CI->db->select('a.*,b.username,b.nickname');
            $CI->db->from('hf_friend_news as a');
            $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
            $query = $CI->db->where('categoryid',$cateid)->where('q_id',$special)->like('content',$sear,'both')->where('likeNumber >=',$likenum)->where('create_news_time >=',$time)->where('create_news_time <=',$endtime)->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
          
        }elseif(empty($cateid) && empty($sear) && empty($special) && empty($time) && empty($likenum)){
             $CI->db->select('a.*,b.username,b.nickname');
        $CI->db->from('hf_friend_news as a');
        $CI->db->join('hf_user_member as b','a.userid = b.user_id','left');
        $query = $CI->db->order_by('type_name','desc')->order_by('a.create_news_time','desc')->get();
            $res = $query->result_array();
        }
        return $res;
}

 ?>